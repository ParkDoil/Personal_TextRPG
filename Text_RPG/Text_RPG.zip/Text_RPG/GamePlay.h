#pragma once

#include "Common.h"

#include "Battle.h"
#include "Shop.h"
#include "Monster.h"
#include "Player.h"

void GamePlay();