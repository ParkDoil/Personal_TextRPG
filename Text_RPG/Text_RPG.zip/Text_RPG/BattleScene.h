#pragma once

#include "Common.h"
#include "Player.h"
#include "Monster.h"
#include "Battle.h"

void BattleScene(Player& player, Monster& monster, Battle& battle);