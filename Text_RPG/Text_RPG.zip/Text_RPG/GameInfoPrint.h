#pragma once

void PrintTitle();

int HowToPlay();

int PrintMainScreen();